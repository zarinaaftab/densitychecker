import { useMemo, useState } from 'react';
import type { FormEvent } from 'react';
import {
  AlertCircle,
  ArrowUpRight,
  BarChart3,
  Check,
  ChevronDown,
  Clipboard,
  FileText,
  Globe2,
  Info,
  LoaderCircle,
  LockKeyhole,
  Menu,
  Search,
  Sparkles,
  Type,
  X,
} from 'lucide-react';
import {
  useAnalyzeKeywordDensity,
  type KeywordDensityInput,
  type KeywordDensityItem,
  type KeywordDensityReport,
} from '@workspace/api-client-react';

const SAMPLE_TEXT =
  'Great content earns attention because it answers a real question clearly. Search engines reward useful content, but readers reward content that sounds human. Use your target keyword naturally, then make every paragraph earn its place.';

type SourceType = KeywordDensityInput['sourceType'];

function formatDate(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return 'Just now';
  return new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric', year: 'numeric' }).format(date);
}

function percent(value: number) {
  return `${value.toFixed(2)}%`;
}

function getErrorMessage(error: unknown) {
  if (error && typeof error === 'object' && 'response' in error) {
    const response = (error as { response?: { data?: { error?: string } } }).response;
    if (response?.data?.error) return response.data.error;
  }
  if (error instanceof Error && error.message) return error.message;
  return 'We could not analyze that source. Check it and try again.';
}

function LevelPill({ level }: { level: KeywordDensityItem['level'] }) {
  const config = {
    low: { label: 'Low', className: 'bg-slate-100 text-slate-600' },
    balanced: { label: 'Balanced', className: 'bg-[#e5f2af] text-[#3d5111]' },
    high: { label: 'High', className: 'bg-[#f9d8d1] text-[#9a3e32]' },
  }[level];
  return <span className={`rounded-full px-2.5 py-1 text-[11px] font-bold tracking-wide ${config.className}`}>{config.label}</span>;
}

function Metric({ label, value, detail }: { label: string; value: string | number; detail?: string }) {
  return (
    <div className="border-l border-[#d9ded9] pl-4 first:border-l-0 first:pl-0">
      <p className="font-mono-ui text-[10px] font-medium uppercase tracking-[.14em] text-[#78817f]">{label}</p>
      <p className="mt-1 font-display text-2xl font-semibold tracking-tight text-[#183041]" data-testid={`metric-${label.toLowerCase().replaceAll(' ', '-')}`}>{value}</p>
      {detail && <p className="mt-0.5 text-[11px] text-[#78817f]">{detail}</p>}
    </div>
  );
}

function KeywordRow({ item }: { item: KeywordDensityItem }) {
  const width = Math.min(100, Math.max(8, item.density * 18));
  return (
    <tr className="group border-b border-[#edf0eb] transition-colors hover:bg-[#fafbf4]" data-testid={`row-keyword-${item.rank}`}>
      <td className="w-14 py-4 pl-5 font-mono-ui text-xs text-[#9aa29d]">{String(item.rank).padStart(2, '0')}</td>
      <td className="py-4 pr-3">
        <div className="flex min-w-0 items-center gap-3">
          <span className="truncate font-semibold text-[#263d49]" data-testid={`text-term-${item.rank}`}>{item.term}</span>
          <div className="hidden h-1.5 min-w-16 flex-1 rounded-full bg-[#edf0eb] sm:block">
            <div className="h-full rounded-full bg-[#b9d84b] transition-all duration-500 group-hover:bg-[#94b923]" style={{ width: `${width}%` }} />
          </div>
        </div>
      </td>
      <td className="w-20 py-4 text-right font-mono-ui text-xs text-[#556665]">{item.count}</td>
      <td className="w-24 py-4 text-right font-mono-ui text-xs font-medium text-[#183041]">{percent(item.density)}</td>
      <td className="w-28 py-4 pr-5 text-right"><LevelPill level={item.level} /></td>
    </tr>
  );
}

function ReportPanel({ report }: { report: KeywordDensityReport }) {
  const [tab, setTab] = useState<'keywords' | 'phrases'>('keywords');
  const [copied, setCopied] = useState(false);
  const rows = tab === 'keywords' ? report.items : report.phrases;

  const copyPreview = async () => {
    await navigator.clipboard?.writeText(report.preview);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1600);
  };

  return (
    <section className="animate-rise animate-rise-delay-1 mt-8 overflow-hidden rounded-2xl border border-[#dce2d9] bg-[#fffef9] shadow-[0_18px_45px_rgba(24,48,65,.07)]" data-testid="section-report">
      <div className="border-b border-[#dce2d9] bg-[#f1f4e9] px-5 py-5 sm:px-7">
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-start">
          <div>
            <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[.15em] text-[#73806c]">
              <span className="inline-flex h-2 w-2 rounded-full bg-[#a5c73b]" />
              Analysis complete
              <span className="text-[#a3aaa1]">/</span>
              {formatDate(report.analyzedAt)}
            </div>
            <h2 className="mt-2 max-w-2xl truncate font-display text-xl font-semibold tracking-tight text-[#183041] sm:text-2xl" data-testid="text-report-title">{report.title || report.source}</h2>
            <p className="mt-1 max-w-2xl truncate text-xs text-[#73807c]" data-testid="text-report-source">{report.source}</p>
          </div>
          <div className="flex items-center gap-2 self-start rounded-full border border-[#d7dfce] bg-[#fbfcf4] px-3 py-1.5 text-[11px] font-medium text-[#64745e]">
            <LockKeyhole className="h-3.5 w-3.5" />
            Private analysis
          </div>
        </div>
        <div className="mt-7 grid grid-cols-2 gap-y-5 sm:grid-cols-5 sm:gap-y-0">
          <Metric label="Words" value={report.totalWords.toLocaleString()} />
          <Metric label="Unique" value={report.uniqueWords.toLocaleString()} detail={`${report.totalWords ? Math.round((report.uniqueWords / report.totalWords) * 100) : 0}% vocabulary`} />
          <Metric label="Sentences" value={report.sentences} />
          <Metric label="Paragraphs" value={report.paragraphs} />
          <Metric label="Read time" value={`${report.readingTimeMinutes} min`} />
        </div>
      </div>

      <div className="px-5 py-6 sm:px-7">
        <div className="flex flex-col justify-between gap-3 border-b border-[#dce2d9] pb-3 sm:flex-row sm:items-end">
          <div>
            <p className="font-mono-ui text-[10px] font-medium uppercase tracking-[.16em] text-[#84908a]">Frequency map</p>
            <h3 className="mt-1 font-display text-lg font-semibold text-[#183041]">What your content repeats</h3>
          </div>
          <div className="flex items-center gap-1 rounded-lg bg-[#f0f2eb] p-1" role="tablist" aria-label="Report view">
            <button type="button" onClick={() => setTab('keywords')} className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors ${tab === 'keywords' ? 'bg-[#fffef9] text-[#183041] shadow-sm' : 'text-[#78817f] hover:text-[#183041]'}`} role="tab" aria-selected={tab === 'keywords'} data-testid="tab-keywords">
              Keywords <span className="ml-1 text-[10px] opacity-60">{report.items.length}</span>
            </button>
            <button type="button" onClick={() => setTab('phrases')} className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors ${tab === 'phrases' ? 'bg-[#fffef9] text-[#183041] shadow-sm' : 'text-[#78817f] hover:text-[#183041]'}`} role="tab" aria-selected={tab === 'phrases'} data-testid="tab-phrases">
              Phrases <span className="ml-1 text-[10px] opacity-60">{report.phrases.length}</span>
            </button>
          </div>
        </div>

        {rows.length ? (
          <div className="mt-2 overflow-x-auto">
            <table className="w-full min-w-[620px] border-collapse text-sm">
              <thead>
                <tr className="font-mono-ui text-[10px] uppercase tracking-[.13em] text-[#98a19a]">
                  <th className="w-14 py-3 pl-5 text-left font-medium">#</th>
                  <th className="py-3 text-left font-medium">Term</th>
                  <th className="w-20 py-3 text-right font-medium">Count</th>
                  <th className="w-24 py-3 text-right font-medium">Density</th>
                  <th className="w-28 py-3 pr-5 text-right font-medium">Read</th>
                </tr>
              </thead>
              <tbody>{rows.map((item) => <KeywordRow key={`${tab}-${item.rank}-${item.term}`} item={item} />)}</tbody>
            </table>
          </div>
        ) : (
          <div className="flex items-center gap-3 py-12 text-sm text-[#78817f]" data-testid="empty-phrases">
            <Info className="h-4 w-4 text-[#9cbf36]" />
            No phrases were detected in this source. Try enabling phrase analysis for a broader read.
          </div>
        )}

        <div className="mt-8 rounded-xl border border-[#e5e9df] bg-[#f8f9f3] p-4 sm:p-5">
          <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-md bg-[#dfeead] text-[#5b711f]"><FileText className="h-3.5 w-3.5" /></div>
              <p className="text-xs font-semibold text-[#42534e]">Source preview</p>
            </div>
            <button type="button" onClick={copyPreview} className="inline-flex w-fit items-center gap-1.5 text-xs font-semibold text-[#687a36] transition-colors hover:text-[#3f5118]" data-testid="button-copy-preview">
              {copied ? <Check className="h-3.5 w-3.5" /> : <Clipboard className="h-3.5 w-3.5" />}
              {copied ? 'Copied' : 'Copy preview'}
            </button>
          </div>
          <p className="mt-3 line-clamp-3 text-sm leading-6 text-[#6e7974]" data-testid="text-preview">{report.preview}</p>
        </div>
      </div>
    </section>
  );
}

function LoadingReport() {
  return (
    <section className="mt-8 overflow-hidden rounded-2xl border border-[#dce2d9] bg-[#fffef9] shadow-[0_18px_45px_rgba(24,48,65,.05)]" aria-label="Analyzing content" data-testid="loading-report">
      <div className="space-y-3 border-b border-[#dce2d9] bg-[#f1f4e9] px-5 py-6 sm:px-7">
        <div className="skeleton-bar h-3 w-28 rounded-full bg-[#d8e2bd]" />
        <div className="skeleton-bar h-7 w-3/5 rounded-md bg-[#d8e2bd]" />
        <div className="skeleton-bar h-3 w-2/5 rounded-full bg-[#d8e2bd]" />
      </div>
      <div className="space-y-4 px-5 py-7 sm:px-7">
        {[100, 75, 88, 64, 80].map((width) => <div key={width} className="skeleton-bar h-12 rounded-lg bg-[#f0f2eb]" style={{ width: `${width}%` }} />)}
      </div>
    </section>
  );
}

export default function Home() {
  const [sourceType, setSourceType] = useState<SourceType>('text');
  const [content, setContent] = useState('');
  const [includePhrases, setIncludePhrases] = useState(true);
  const [includeStopWords, setIncludeStopWords] = useState(false);
  const analyze = useAnalyzeKeywordDensity();
  const report = analyze.data;
  const wordCount = useMemo(() => content.trim() ? content.trim().split(/\s+/).length : 0, [content]);

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const trimmed = content.trim();
    if (!trimmed || analyze.isPending) return;
    analyze.mutate({ data: { sourceType, content: trimmed, includePhrases, includeStopWords } });
  };

  const handleSample = () => {
    setSourceType('text');
    setContent(SAMPLE_TEXT);
  };

  return (
    <div className="noise min-h-[100dvh] bg-[#f7f7f1]">
      <header className="mx-auto flex max-w-[1240px] items-center justify-between px-5 py-5 sm:px-8 lg:px-10" data-testid="header-main">
        <div className="flex items-center gap-3">
          <div className="relative flex h-9 w-9 items-center justify-center rounded-[10px] bg-[#183041] text-[#d4ef5e] shadow-[3px_3px_0_#bdd243]">
            <span className="font-display text-lg font-bold">K</span>
            <span className="absolute -right-1 -top-1 h-2 w-2 rounded-full bg-[#d4ef5e]" />
          </div>
          <div>
            <p className="font-display text-[15px] font-bold tracking-[-.02em] text-[#183041]">keyword / density</p>
            <p className="font-mono-ui text-[9px] uppercase tracking-[.15em] text-[#83908a]">content instrument</p>
          </div>
        </div>
        <div className="hidden items-center gap-5 text-xs font-semibold text-[#7a8580] sm:flex">
          <span className="inline-flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-[#a9c43d]" /> No signup required</span>
          <span className="inline-flex items-center gap-1.5"><LockKeyhole className="h-3.5 w-3.5" /> Your text stays private</span>
        </div>
        <button type="button" className="rounded-lg p-2 text-[#60706a] hover:bg-[#eaeee3] sm:hidden" data-testid="button-mobile-menu" aria-label="Open menu"><Menu className="h-5 w-5" /></button>
      </header>

      <main className="mx-auto max-w-[1240px] px-5 pb-16 sm:px-8 lg:px-10">
        <section className="relative overflow-hidden rounded-[22px] border border-[#dfe4d8] bg-[#edf2df] px-5 py-9 sm:px-10 sm:py-12 lg:px-14 lg:py-14">
          <div className="pointer-events-none absolute -right-20 -top-24 h-72 w-72 rounded-full border-[38px] border-[#d8e8a2] opacity-70" />
          <div className="pointer-events-none absolute -right-8 top-16 hidden h-56 w-56 rotate-12 border border-[#cbdc81] opacity-60 sm:block" />
          <div className="relative max-w-3xl">
            <div className="animate-rise inline-flex items-center gap-2 rounded-full border border-[#d4dfb7] bg-[#f6f8e9] px-3 py-1.5 font-mono-ui text-[10px] uppercase tracking-[.16em] text-[#647532]">
              <Sparkles className="h-3.5 w-3.5" /> Instant content readout
            </div>
            <h1 className="animate-rise animate-rise-delay-1 mt-5 max-w-3xl font-display text-[clamp(2.55rem,6vw,5.4rem)] font-semibold leading-[.97] tracking-[-.065em] text-[#183041]">
              Make every word<br /><span className="text-[#91ad2c]">pull its weight.</span>
            </h1>
            <p className="animate-rise animate-rise-delay-2 mt-5 max-w-xl text-sm leading-6 text-[#60706a] sm:text-base">
              A fast, clear keyword density check for writing that sounds natural — not stuffed. Paste your draft or point us to a public page.
            </p>
          </div>
          <div className="pointer-events-none absolute bottom-7 right-12 hidden items-end gap-1.5 opacity-50 lg:flex">
            {[32, 56, 42, 77, 62, 88, 50, 70].map((height, index) => <span key={index} className="w-2 rounded-t-sm bg-[#9ab536]" style={{ height }} />)}
          </div>
        </section>

        <section className="mx-auto -mt-5 max-w-[1070px] animate-rise animate-rise-delay-2">
          <form onSubmit={handleSubmit} className="rounded-2xl border border-[#d8dfd5] bg-[#fffef9] p-3 shadow-[0_18px_38px_rgba(24,48,65,.1)] sm:p-4" data-testid="form-analyzer">
            <div className="flex flex-wrap items-center gap-1 rounded-xl bg-[#f1f3ed] p-1">
              <button type="button" onClick={() => setSourceType('text')} className={`inline-flex items-center gap-2 rounded-lg px-4 py-2.5 text-xs font-bold transition-all ${sourceType === 'text' ? 'bg-[#fffef9] text-[#183041] shadow-sm' : 'text-[#7b8780] hover:text-[#183041]'}`} data-testid="button-source-text">
                <Type className="h-3.5 w-3.5" /> Paste text
              </button>
              <button type="button" onClick={() => setSourceType('url')} className={`inline-flex items-center gap-2 rounded-lg px-4 py-2.5 text-xs font-bold transition-all ${sourceType === 'url' ? 'bg-[#fffef9] text-[#183041] shadow-sm' : 'text-[#7b8780] hover:text-[#183041]'}`} data-testid="button-source-url">
                <Globe2 className="h-3.5 w-3.5" /> Public URL
              </button>
              <span className="ml-auto hidden pr-3 font-mono-ui text-[10px] text-[#a0aaa2] sm:block">STEP 01 / SOURCE</span>
            </div>
            <div className="relative mt-3">
              {sourceType === 'text' ? (
                <textarea value={content} onChange={(event) => setContent(event.target.value)} className="min-h-[172px] w-full resize-y rounded-xl border border-[#e1e6de] bg-[#fcfcf8] px-4 py-4 text-sm leading-6 text-[#263d49] outline-none transition-colors placeholder:text-[#adb6ae] focus:border-[#afc941] focus:ring-2 focus:ring-[#dce9a9] sm:min-h-[188px]" placeholder="Paste an article, landing page, or draft here…" data-testid="input-content-text" />
              ) : (
                <div className="flex min-h-[172px] items-center justify-center rounded-xl border border-[#e1e6de] bg-[#fcfcf8] px-4 sm:min-h-[188px]">
                  <div className="w-full max-w-2xl">
                    <label htmlFor="url-input" className="mb-2 block font-mono-ui text-[10px] uppercase tracking-[.14em] text-[#87948d]">Public page address</label>
                    <div className="flex items-center gap-3 rounded-xl border border-[#d9e1d7] bg-[#fffef9] px-4 py-3 focus-within:border-[#afc941] focus-within:ring-2 focus-within:ring-[#dce9a9]">
                      <Search className="h-4 w-4 shrink-0 text-[#91a194]" />
                      <input id="url-input" value={content} onChange={(event) => setContent(event.target.value)} type="url" className="w-full bg-transparent text-sm text-[#263d49] outline-none placeholder:text-[#adb6ae]" placeholder="https://example.com/article" data-testid="input-content-url" />
                      {content && <button type="button" onClick={() => setContent('')} className="text-[#8b9891] hover:text-[#183041]" data-testid="button-clear-url" aria-label="Clear URL"><X className="h-4 w-4" /></button>}
                    </div>
                    <p className="mt-3 text-center text-xs text-[#9aa49e]">We’ll read the publicly available page text. No login or tracking.</p>
                  </div>
                </div>
              )}
              {sourceType === 'text' && <div className="pointer-events-none absolute bottom-3 right-3 rounded bg-[#f1f3ed] px-2 py-1 font-mono-ui text-[10px] text-[#9aa49e]">{wordCount.toLocaleString()} words</div>}
            </div>
            <div className="flex flex-col gap-4 px-1 pt-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex flex-wrap items-center gap-x-5 gap-y-3">
                <label className="inline-flex cursor-pointer items-center gap-2 text-xs font-semibold text-[#66736d]">
                  <input type="checkbox" checked={includePhrases} onChange={(event) => setIncludePhrases(event.target.checked)} className="peer sr-only" data-testid="input-include-phrases" />
                  <span className={`flex h-4 w-4 items-center justify-center rounded border transition-colors ${includePhrases ? 'border-[#a9c63e] bg-[#c9e85d] text-[#34470f]' : 'border-[#cbd5cc] bg-transparent'}`}>{includePhrases && <Check className="h-3 w-3" />}</span>
                  Include phrases
                </label>
                <label className="inline-flex cursor-pointer items-center gap-2 text-xs font-semibold text-[#66736d]">
                  <input type="checkbox" checked={includeStopWords} onChange={(event) => setIncludeStopWords(event.target.checked)} className="peer sr-only" data-testid="input-include-stop-words" />
                  <span className={`flex h-4 w-4 items-center justify-center rounded border transition-colors ${includeStopWords ? 'border-[#a9c63e] bg-[#c9e85d] text-[#34470f]' : 'border-[#cbd5cc] bg-transparent'}`}>{includeStopWords && <Check className="h-3 w-3" />}</span>
                  Count stop words
                </label>
                {sourceType === 'text' && <button type="button" onClick={handleSample} className="text-xs font-semibold text-[#87952f] underline decoration-[#c9e85d] underline-offset-4 hover:text-[#52651a]" data-testid="button-use-sample">Try sample</button>}
              </div>
              <button type="submit" disabled={!content.trim() || analyze.isPending} className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#183041] px-5 py-3 text-xs font-bold text-[#eff7c9] shadow-[3px_3px_0_#b8d546] transition-all hover:-translate-y-0.5 hover:bg-[#223e50] active:translate-y-0 disabled:cursor-not-allowed disabled:opacity-50 disabled:shadow-none" data-testid="button-analyze">
                {analyze.isPending ? <><LoaderCircle className="h-4 w-4 animate-spin" /> Reading source…</> : <><BarChart3 className="h-4 w-4" /> Analyze density <ArrowUpRight className="h-3.5 w-3.5" /></>}
              </button>
            </div>
          </form>
        </section>

        {analyze.isPending && <LoadingReport />}
        {analyze.error && !analyze.isPending && (
          <div className="mt-8 flex items-start gap-3 rounded-2xl border border-[#efc9c1] bg-[#fff6f3] p-5 text-sm text-[#8f4338]" role="alert" data-testid="status-error">
            <AlertCircle className="mt-0.5 h-5 w-5 shrink-0" />
            <div className="flex-1"><p className="font-bold">That source could not be read.</p><p className="mt-1 text-xs leading-5 text-[#a8645a]">{getErrorMessage(analyze.error)}</p></div>
            <button type="button" onClick={() => analyze.reset()} className="rounded-md p-1 text-[#a8645a] hover:bg-[#f8e2dc]" data-testid="button-dismiss-error" aria-label="Dismiss error"><X className="h-4 w-4" /></button>
          </div>
        )}
        {report && !analyze.isPending && <ReportPanel report={report} />}

        {!report && !analyze.isPending && !analyze.error && (
          <div className="mx-auto mt-10 grid max-w-[1070px] gap-8 border-t border-[#e0e4dc] pt-8 sm:grid-cols-[1fr_auto] sm:items-start">
            <div>
              <p className="font-mono-ui text-[10px] uppercase tracking-[.16em] text-[#99a39d]">How to read the signal</p>
              <div className="mt-4 grid gap-4 sm:grid-cols-3">
                <div className="flex gap-3"><span className="font-display text-2xl font-bold text-[#a5bf3c]">01</span><p className="text-xs leading-5 text-[#6f7b75]">Start with the terms that define your topic.</p></div>
                <div className="flex gap-3"><span className="font-display text-2xl font-bold text-[#a5bf3c]">02</span><p className="text-xs leading-5 text-[#6f7b75]">Check density in context, never in isolation.</p></div>
                <div className="flex gap-3"><span className="font-display text-2xl font-bold text-[#a5bf3c]">03</span><p className="text-xs leading-5 text-[#6f7b75]">Edit for the reader first. Search follows.</p></div>
              </div>
            </div>
            <div className="hidden items-center gap-2 rounded-lg border border-[#dfe5d9] bg-[#fbfcf7] px-3 py-2 text-[11px] text-[#7d8981] sm:flex"><LockKeyhole className="h-3.5 w-3.5 text-[#9bb23f]" /> No content stored</div>
          </div>
        )}
      </main>
      <footer className="mx-auto flex max-w-[1240px] items-center justify-between border-t border-[#e0e4dc] px-5 py-6 text-[11px] text-[#98a19a] sm:px-8 lg:px-10">
        <span className="font-mono-ui">K / density checker</span>
        <span>Built for better writing.</span>
      </footer>
    </div>
  );
}