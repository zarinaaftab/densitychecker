import { Router, type IRouter } from "express";
import healthRouter from "./health";
import keywordDensityRouter from "./keyword-density";

const router: IRouter = Router();

router.use(healthRouter);
router.use(keywordDensityRouter);

export default router;
