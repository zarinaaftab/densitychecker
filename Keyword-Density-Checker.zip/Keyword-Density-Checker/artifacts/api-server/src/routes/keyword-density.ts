import { Router, type IRouter } from "express";
import {
  AnalyzeKeywordDensityBody,
  AnalyzeKeywordDensityResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

const STOP_WORDS = new Set(
  [
    "a",
    "about",
    "above",
    "after",
    "again",
    "against",
    "all",
    "also",
    "am",
    "an",
    "and",
    "any",
    "are",
    "as",
    "at",
    "be",
    "because",
    "been",
    "before",
    "being",
    "below",
    "between",
    "both",
    "but",
    "by",
    "can",
    "could",
    "did",
    "do",
    "does",
    "doing",
    "down",
    "during",
    "each",
    "few",
    "for",
    "from",
    "further",
    "had",
    "has",
    "have",
    "having",
    "he",
    "her",
    "here",
    "hers",
    "herself",
    "him",
    "himself",
    "his",
    "how",
    "i",
    "if",
    "in",
    "into",
    "is",
    "it",
    "its",
    "itself",
    "just",
    "me",
    "more",
    "most",
    "my",
    "myself",
    "no",
    "nor",
    "not",
    "now",
    "of",
    "off",
    "on",
    "once",
    "only",
    "or",
    "other",
    "our",
    "ours",
    "ourselves",
    "out",
    "over",
    "own",
    "same",
    "she",
    "should",
    "so",
    "some",
    "such",
    "than",
    "that",
    "the",
    "their",
    "theirs",
    "them",
    "themselves",
    "then",
    "there",
    "these",
    "they",
    "this",
    "those",
    "through",
    "to",
    "too",
    "under",
    "until",
    "up",
    "very",
    "was",
    "we",
    "were",
    "what",
    "when",
    "where",
    "which",
    "while",
    "who",
    "whom",
    "why",
    "will",
    "with",
    "you",
    "your",
    "yours",
    "yourself",
    "yourselves",
  ].map((word) => word),
);

const TOKEN_PATTERN = /[\p{L}\p{N}]+(?:['’\-][\p{L}\p{N}]+)*/gu;

type DensityLevel = "low" | "balanced" | "high";

type DensityItem = {
  term: string;
  count: number;
  density: number;
  rank: number;
  level: DensityLevel;
};

function getTokens(text: string): string[] {
  return text.toLocaleLowerCase().match(TOKEN_PATTERN) ?? [];
}

function densityLevel(density: number): DensityLevel {
  if (density >= 3) return "high";
  if (density >= 0.8) return "balanced";
  return "low";
}

function toItems(
  counts: Map<string, number>,
  totalWords: number,
  limit: number,
): DensityItem[] {
  return [...counts.entries()]
    .sort(([termA, countA], [termB, countB]) => {
      return countB - countA || termA.localeCompare(termB);
    })
    .slice(0, limit)
    .map(([term, count], index) => {
      const density = Number(((count / Math.max(totalWords, 1)) * 100).toFixed(2));
      return {
        term,
        count,
        density,
        rank: index + 1,
        level: densityLevel(density),
      };
    });
}

function decodeHtmlEntities(value: string): string {
  return value
    .replace(/&#(\d+);/g, (_, code: string) =>
      String.fromCodePoint(Number(code)),
    )
    .replace(/&#x([0-9a-f]+);/gi, (_, code: string) =>
      String.fromCodePoint(Number.parseInt(code, 16)),
    )
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&apos;/gi, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">");
}

function extractHtml(html: string): { text: string; title: string } {
  const title =
    decodeHtmlEntities(html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] ?? "")
      .replace(/\s+/g, " ")
      .trim() || "Web page";
  const content = html
    .replace(/<(script|style|noscript|svg|template)[^>]*>[\s\S]*?<\/\1>/gi, " ")
    .replace(/<(br|\/p|\/div|\/li|\/h[1-6]|\/article|\/section)[^>]*>/gi, "\n")
    .replace(/<[^>]+>/g, " ");
  return {
    text: decodeHtmlEntities(content).replace(/\s+/g, " ").trim(),
    title,
  };
}

function isBlockedHostname(hostname: string): boolean {
  const host = hostname.toLowerCase();
  if (
    host === "localhost" ||
    host === "::1" ||
    host === "0.0.0.0" ||
    host.endsWith(".localhost") ||
    host.endsWith(".local")
  ) {
    return true;
  }
  const octets = host.split(".").map(Number);
  if (octets.length !== 4 || octets.some((octet) => Number.isNaN(octet))) {
    return false;
  }
  const [first, second] = octets;
  return (
    first === 10 ||
    first === 127 ||
    (first === 172 && second >= 16 && second <= 31) ||
    (first === 192 && second === 168)
  );
}

async function getSourceContent(
  sourceType: "text" | "url",
  content: string,
): Promise<{ text: string; title: string; source: string }> {
  if (sourceType === "text") {
    return { text: content, title: "Pasted text", source: "Pasted text" };
  }

  let url: URL;
  try {
    url = new URL(content);
  } catch {
    throw new Error("Enter a complete URL, including https://");
  }
  if (!["http:", "https:"].includes(url.protocol) || isBlockedHostname(url.hostname)) {
    throw new Error("Only public http:// or https:// URLs can be analyzed.");
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12_000);
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        "user-agent": "KeywordDensityChecker/1.0 (+https://replit.com)",
        accept: "text/html,application/xhtml+xml",
      },
    });
    if (!response.ok) {
      throw new Error(`The page returned ${response.status}.`);
    }
    const html = (await response.text()).slice(0, 2_000_000);
    const extracted = extractHtml(html);
    if (getTokens(extracted.text).length === 0) {
      throw new Error("We could not find readable text on that page.");
    }
    return { ...extracted, source: url.toString() };
  } catch (error) {
    if (error instanceof Error && error.name === "AbortError") {
      throw new Error("The page took too long to respond. Try pasting the text instead.");
    }
    throw error instanceof Error ? error : new Error("Unable to read that page.");
  } finally {
    clearTimeout(timeout);
  }
}

function analyzeText(
  text: string,
  includePhrases: boolean,
  includeStopWords: boolean,
): {
  totalWords: number;
  uniqueWords: number;
  sentences: number;
  paragraphs: number;
  readingTimeMinutes: number;
  items: DensityItem[];
  phrases: DensityItem[];
  preview: string;
} {
  const allTokens = getTokens(text);
  const tokens = includeStopWords
    ? allTokens
    : allTokens.filter((token) => !STOP_WORDS.has(token));
  const counts = new Map<string, number>();
  for (const token of tokens) counts.set(token, (counts.get(token) ?? 0) + 1);

  const phrases = new Map<string, number>();
  if (includePhrases) {
    const phraseTokens = includeStopWords
      ? allTokens
      : allTokens.filter((token) => !STOP_WORDS.has(token));
    for (let index = 0; index < phraseTokens.length - 1; index += 1) {
      const phrase = `${phraseTokens[index]} ${phraseTokens[index + 1]}`;
      phrases.set(phrase, (phrases.get(phrase) ?? 0) + 1);
    }
  }

  return {
    totalWords: allTokens.length,
    uniqueWords: new Set(allTokens).size,
    sentences: Math.max(1, (text.match(/[.!?]+(?=\s|$)/g) ?? []).length),
    paragraphs: Math.max(1, text.split(/\n\s*\n/).filter((paragraph) => paragraph.trim()).length),
    readingTimeMinutes: Math.max(1, Math.ceil(allTokens.length / 220)),
    items: toItems(counts, allTokens.length, 12),
    phrases: toItems(phrases, allTokens.length, 8),
    preview: text.replace(/\s+/g, " ").trim().slice(0, 280),
  };
}

router.post("/keyword-density/analyze", async (req, res) => {
  const parsed = AnalyzeKeywordDensityBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Add some text or a valid URL to analyze." });
    return;
  }

  try {
    const { sourceType, content, includePhrases, includeStopWords } = parsed.data;
    const sourceContent = await getSourceContent(sourceType, content);
    const report = AnalyzeKeywordDensityResponse.parse({
      ...sourceContent,
      ...analyzeText(sourceContent.text, includePhrases, includeStopWords),
      sourceType,
      analyzedAt: new Date().toISOString(),
    });
    req.log.info(
      { sourceType, totalWords: report.totalWords },
      "Keyword density analysis completed",
    );
    res.json(report);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Analysis failed.";
    req.log.warn({ err: error }, "Keyword density analysis failed");
    res.status(400).json({ error: message });
  }
});

export default router;