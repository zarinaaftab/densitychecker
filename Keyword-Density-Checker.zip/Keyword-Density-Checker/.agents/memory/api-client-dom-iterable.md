---
name: API client DOM iterable compatibility
description: TypeScript library settings needed by generated request helpers.
---

Generated API client code may call `Headers.entries()`. The API client package must include `dom.iterable` alongside `dom` in its TypeScript `lib` list.

**Why:** Orval-generated fetch helpers typecheck against iterable DOM collection methods that are not included by the plain `dom` library.

**How to apply:** If codegen succeeds but the shared API client reports a missing `Headers.entries`, check the API client's `tsconfig.json` before changing generated output.